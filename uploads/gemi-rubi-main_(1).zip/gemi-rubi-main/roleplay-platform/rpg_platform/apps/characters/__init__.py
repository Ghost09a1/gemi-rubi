default_app_config = 'rpg_platform.apps.characters.apps.CharactersConfig'
