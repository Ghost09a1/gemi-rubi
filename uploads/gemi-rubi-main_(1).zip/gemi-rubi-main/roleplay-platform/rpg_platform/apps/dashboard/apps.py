from django.apps import AppConfig


class DashboardConfig(AppConfig):
    name = 'rpg_platform.apps.dashboard'
    verbose_name = 'Dashboard'
