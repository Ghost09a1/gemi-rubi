default_app_config = 'rpg_platform.apps.accounts.apps.AccountsConfig'
